from collections import namedtuple
from math import sqrt
import random
import numpy as np
try:
    import Image
except ImportError:
    from PIL import Image


Point = namedtuple('Point', ('coords', 'n', 'ct'))
Cluster = namedtuple('Cluster', ('points', 'center', 'n'))


def get_points(img):
    points = []
    w, h = img.size
    for count, color in img.getcolors(w * h):
        points.append(Point(color, 3, count))
    return points

rtoh = lambda rgb: '#%s' % ''.join(('%02x' % p for p in rgb))

def colorz(filename, n=3):
    img = Image.open(filename)
    img.thumbnail((200, 200))
    w, h = img.size

    points = get_points(img)
    clusters = kmeans(points, n, 1)
    rgbs = [map(int, c.center.coords) for c in clusters]
    
    # print(clusters)
    # print(list(clusters))

    return map(rtoh, rgbs)

def euclidean(p1, p2):
    return sqrt(sum([
        (p1.coords[i] - p2.coords[i]) ** 2 for i in range(p1.n)
    ]))

def calculate_center(points, n):
    vals = [0.0 for i in range(n)]
    plen = 0
    for p in points:
        plen += p.ct
        for i in range(n):
            vals[i] += (p.coords[i] * p.ct)
    return Point([(v / plen) for v in vals], n, 1)
    
def kmeans(points, k, min_diff):
    clusters = [Cluster([p], p, p.n) for p in random.sample(points, k)]

    while 1:
        plists = [[] for i in range(k)]

        for p in points:
            smallest_distance = float('Inf')
            for i in range(k):
                distance = euclidean(p, clusters[i].center)
                if distance < smallest_distance:
                    smallest_distance = distance
                    idx = i
            plists[idx].append(p)

        diff = 0
        for i in range(k):
            old = clusters[i]
            center = calculate_center(plists[i], old.n)
            new = Cluster(plists[i], center, old.n)
            clusters[i] = new
            diff = max(diff, euclidean(old.center, new.center))

        if diff < min_diff:
            break

    return clusters



def skintone(filename):

    fx = [[213,168,139], [184,119,79], [184,108,58], [146,76,50], [133,75,55], [54,41,35], [236,208,184], [231,196,174], [231,192,176]]

    clusters = list(colorz(filename, 1))

    # print(list(clusters))

    # print(list(map(RGB2HEX, clusters)))

    print(clusters[0])
    print(hex_to_rgb(clusters[0]))
        
    temp = hex_to_rgb(clusters[0])

    minDistance = np.inf 

    min_value = [0, 0, 0]

    for x in fx:

        sum = np.abs(temp[0] - x[0]) + np.abs(temp[1] - x[1]) + np.abs(temp[2] - x[2])
        if sum < minDistance:
            minDistance = sum
            min_value = x

    print(min_value)
    print('MIN_VALUE')
    return RGB2HEX(min_value)

def RGB2HEX(color):
    
    return "{:02x}{:02x}{:02x}".format(int(color[0]), int(color[1]), int(color[2]))

def hex_to_rgb(value):
    value = value.lstrip('#')
    lv = len(value)
    return tuple(int(value[i:i + lv // 3], 16) for i in range(0, lv, lv // 3))


