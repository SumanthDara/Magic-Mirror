import pyrebase
#import firebase_config

print("---")

config = {
  "apiKey": "AIzaSyDbhZbnQ97sUwc2a7-JLb1tTiIPS_Bm2gY",
  "authDomain": "magic-mirror-31c85.firebaseapp.com",
  "databaseURL": "https://magic-mirror-31c85.firebaseio.com",
  "storageBucket": "magic-mirror-31c85.appspot.com",
  "serviceAccount": "firebase_service.json"
}

firebase = pyrebase.initialize_app(config)

#firebase_config = firebase_config.set_firebase_config()
#firebase = pyrebase.initialize_app(firebase_config)

auth = firebase.auth()

token = auth.create_custom_token("desk")
user = auth.sign_in_with_custom_token(token)

db = firebase.database()
# foundationHigh = db.child("Magic Mirror").child("362923").child("Dry").child("High").get()
"""
    foundationMed = 
    foundationLow = 
    return

# retrieves patient basic information from firebase
def get_patient_basic_information(patient_id):
    # retrieves from firebase
    patient_basic_information = db.child("patient information").child(patient_id)
    if str(type(patient_basic_information)) == "<class 'NoneType'>":
        return "invalid id"

    print(str(patient_basic_information))
    return patient_basic_information


    """