import pyrebase
import json
from flask import Flask, render_template, request
import os
from flask_uuid import FlaskUUID
import uuid
from detect_color import colorz
from detect_color import skintone

print("---")

config = {
  "apiKey": "AIzaSyDbhZbnQ97sUwc2a7-JLb1tTiIPS_Bm2gY",
  "authDomain": "magic-mirror-31c85.firebaseapp.com",
  "databaseURL": "https://magic-mirror-31c85.firebaseio.com",
  "storageBucket": "magic-mirror-31c85.appspot.com",
  "serviceAccount": "firebase_service.json"
}

firebase = pyrebase.initialize_app(config)
auth = firebase.auth()
token = auth.create_custom_token("desk")
user = auth.sign_in_with_custom_token(token)
db = firebase.database()

app = Flask(__name__)
FlaskUUID(app)

# user ONLY goes to this
@app.route("/access", methods = ['GET', 'POST'])
def access():
	return render_template("test.html")

# this is used by the API (/access)
@app.route("/test", methods = ['GET', 'POST'])
def test(): 
	temp = getFileName()
	f = json.loads(temp)
	n = f['filename']
	print(n)
	minval = skintone(n)
	print(minval)
	
	# foundationHigh = db.child("Magic Mirror").child("362923").child("Dry").child("High").get()

	# v1 = colorz(n, 3)
	# print(v1)
	testdict = {
		'High': {
			"price": "70",
			"name": "L'oreal",
			"link": "www.www"
		},
		'Med':{
			"price": "30",
			"name": "Maybelline",
			"link": "www.123"
		},
		'Low':{
			"price": "10",
			"name": "MAC",
			"link": "www.abc"
		}
	}
	return json.dumps(testdict)
	

def getFileName():
	f_name = "DEFAULT"
	file = request.files['file']
	extension = os.path.splitext(file.filename)[1]
	f_name = str(uuid.uuid4()) + extension
	return json.dumps({'filename': file.filename})

app.run()
